<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST['name']) && isset($_POST['specialization']) && isset($_POST['phone'])) {
        $name = $_POST['name'];
        $specialization = $_POST['specialization'];
        $phone = $_POST['phone'];

        $sql = "INSERT INTO doctors (name, specialization, phone)
                VALUES ('$name', '$specialization', '$phone')";

        if ($conn->query($sql) === TRUE) {
            echo "<p>New doctor added successfully</p>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "<p>All fields are required.</p>";
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Doctor</title>
</head>
<body>
    <h2>Add Doctor</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name"><br>
        
        <label for="specialization">Specialization:</label><br>
        <input type="text" id="specialization" name="specialization"><br>
        
        <label for="phone">Phone:</label><br>
        <input type="text" id="phone" name="phone"><br>
        
        <input type="submit" value="Submit">
    </form>
</body>
</html>
