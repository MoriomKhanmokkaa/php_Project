<?php
include 'db.php';

// Fetch all patients
$patient_query = "SELECT * FROM patients";
$patient_result = $conn->query($patient_query);

if ($patient_result->num_rows > 0) {
    echo "<h2>All Patients Information</h2>";
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Name</th><th>Date of Birth</th><th>Gender</th><th>Address</th><th>Phone</th></tr>";
    while($row = $patient_result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row["id"]."</td>";
        echo "<td>".$row["name"]."</td>";
        echo "<td>".$row["dob"]."</td>";
        echo "<td>".$row["gender"]."</td>";
        echo "<td>".$row["address"]."</td>";
        echo "<td>".$row["phone"]."</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No patients found.";
}

$conn->close();
?>
