<?php
include 'db.php';

// Function to view doctor by ID or Specialization
function searchDoctor($conn, $search_term) {
    // Prepare the SQL statement with a placeholder for the search term
    $sql = "SELECT * FROM doctors WHERE id = ? OR specialization = ?";
    
    // Prepare the statement
    $stmt = $conn->prepare($sql);
    
    // Bind the search term parameter to the statement
    $stmt->bind_param("ss", $search_term, $search_term);
    
    // Execute the statement
    $stmt->execute();
    
    // Get the result
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $output = "<h2>Doctor Information</h2>";
        while ($row = $result->fetch_assoc()) {
            $output .= "<p>ID: " . $row["id"] . "</p>";
            $output .= "<p>Name: " . $row["name"] . "</p>";
            $output .= "<p>Specialization: " . $row["specialization"] . "</p>";
            $output .= "<p>Phone: " . $row["phone"] . "</p>";
            $output .= "<hr>";
        }
        return $output;
    } else {
        return "No doctor found with the provided ID or specialization";
    }
}

// Function to view patient by ID
function searchPatient($conn, $patient_id) {
    $sql = "SELECT * FROM patients WHERE id = $patient_id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return "<h2>Patient Information</h2>
                <p>ID: " . $row["id"] . "</p>
                <p>Name: " . $row["name"] . "</p>
                <p>Date of Birth: " . $row["dob"] . "</p>
                <p>Gender: " . $row["gender"] . "</p>
                <p>Address: " . $row["address"] . "</p>
                <p>Phone: " . $row["phone"] . "</p>";
    } else {
        return "No patient found with the provided ID";
    }
}

// Define variables and initialize with empty values
$search_term = $patient_id = "";
$search_result = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["search_term"])) {
        $search_term = $_POST["search_term"];
        $search_result = searchDoctor($conn, $search_term);
    } elseif (!empty($_POST["patient_id"])) {
        $patient_id = $_POST["patient_id"];
        $search_result = searchPatient($conn, $patient_id);
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search Doctors and Patients</title>
</head>
<body>
    <h2>Search Doctors and Patients</h2>
    
    <!-- Form to search doctor by ID or Specialization -->
    <h3>Search Doctor</h3>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="search_term">Search by Doctor ID or Specialization:</label>
        <input type="text" id="search_term" name="search_term">
        <input type="submit" value="Search Doctor">
    </form>
    
    <!-- Form to search patient by ID -->
    <h3>Search Patient</h3>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="patient_id">Search by Patient ID:</label>
        <input type="text" id="patient_id" name="patient_id">
        <input type="submit" value="Search Patient">
    </form>
    
    <!-- Display search results -->
    <div>
        <?php echo $search_result; ?>
    </div>
</body>
</html>
