<?php
include 'db.php';

// Fetch all doctors
$doctor_query = "SELECT * FROM doctors";
$doctor_result = $conn->query($doctor_query);

if ($doctor_result->num_rows > 0) {
    echo "<h2>All Doctors Information</h2>";
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Name</th><th>Specialization</th></tr>";
    while($row = $doctor_result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row["id"]."</td>";
        echo "<td>".$row["name"]."</td>";
        echo "<td>".$row["specialization"]."</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "No doctors found.";
}

$conn->close();
?>
