<?php
include 'db.php';

// Fetch all doctors
$doctor_query = "SELECT * FROM doctors";
$doctor_result = $conn->query($doctor_query);

// Initialize variables for last patient information
$last_patient_result = null;
$last_patient_row = null;

// Fetch the last added patient
$last_patient_query = "SELECT * FROM patients ORDER BY id DESC LIMIT 1";
$last_patient_result = $conn->query($last_patient_query);

if ($last_patient_result && $last_patient_result->num_rows > 0) {
    $last_patient_row = $last_patient_result->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST['patient_id']) && isset($_POST['doctor_id']) && isset($_POST['appointment_date'])) {
        $patient_id = $_POST['patient_id'];
        $doctor_id = $_POST['doctor_id'];
        $appointment_date = $_POST['appointment_date'];

        $sql = "INSERT INTO appointments (patient_id, doctor_id, appointment_date)
                VALUES ('$patient_id', '$doctor_id', '$appointment_date')";

        if ($conn->query($sql) === TRUE) {
            echo "<p>New appointment scheduled successfully</p>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "<p>All fields are required.</p>";
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Schedule Appointment</title>
</head>
<body>
    <h2>Schedule Appointment</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="patient_id">Patient ID:</label><br>
        <?php 
        if ($last_patient_row && isset($last_patient_row["id"])) {
            echo "<input type='text' id='patient_id' name='patient_id' value='" . $last_patient_row["id"] . "'><br>";
        } else {
            echo "<input type='text' id='patient_id' name='patient_id'><br>";
        }
        ?>
        
        <label for="doctor_id">Doctor:</label><br>
        <select id="doctor_id" name="doctor_id">
            <?php 
            if ($doctor_result && $doctor_result->num_rows > 0) {
                while($row = $doctor_result->fetch_assoc()) {
                    echo "<option value='".$row["id"]."'>".$row["name"]." - ".$row["specialization"]."</option>";
                }
            }
            ?>
        </select><br>
        
        <label for="appointment_date">Appointment Date:</label><br>
        <input type="date" id="appointment_date" name="appointment_date"><br>
        
        <input type="submit" value="Submit">
    </form>
    <?php 
    if ($last_patient_row && isset($last_patient_row["id"])) {
        echo "<h3>Last Added Patient Information:</h3>";
        echo "<p>Name: " . $last_patient_row["name"] . "</p>";
        echo "<p>Date of Birth: " . $last_patient_row["dob"] . "</p>";
        echo "<p>Gender: " . $last_patient_row["gender"] . "</p>";
        echo "<p>Address: " . $last_patient_row["address"] . "</p>";
        echo "<p>Phone: " . $last_patient_row["phone"] . "</p>";
    }
    ?>
    <!-- Button to view all doctors -->
    <form action="view_doctors.php" method="get">
        <input type="submit" value="View All Doctors">
    </form>
    <!-- Button to view all patients -->
    <form action="view_patients.php" method="get">
        <input type="submit" value="View All Patients">
    </form>
</body>
</html>
