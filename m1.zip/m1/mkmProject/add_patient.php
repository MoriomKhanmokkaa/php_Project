<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST['name']) && isset($_POST['dob']) && isset($_POST['gender']) && isset($_POST['address']) && isset($_POST['phone'])) {
        $name = $_POST['name'];
        $dob = $_POST['dob'];
        $gender = $_POST['gender'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];

        $sql = "INSERT INTO patients (name, dob, gender, address, phone)
                VALUES ('$name', '$dob', '$gender', '$address', '$phone')";

        if ($conn->query($sql) === TRUE) {
            echo "<p>New patient added successfully</p>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "<p>All fields are required.</p>";
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Patient</title>
</head>
<body>
    <h2>Add Patient</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name"><br>
        
        <label for="dob">Date of Birth:</label><br>
        <input type="date" id="dob" name="dob"><br>
        
        <label for="gender">Gender:</label><br>
        <select id="gender" name="gender">
            <option value="Male">Male</option>
            <option value="Female">Female</option>
        </select><br>
        
        <label for="address">Address:</label><br>
        <textarea id="address" name="address"></textarea><br>
        
        <label for="phone">Phone:</label><br>
        <input type="text" id="phone" name="phone"><br>
        
        <input type="submit" value="Submit">
    </form>
</body>
</html>
