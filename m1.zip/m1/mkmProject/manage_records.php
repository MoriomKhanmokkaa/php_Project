<?php
include 'db.php';

// Function to delete a doctor by ID
function deleteDoctor($conn, $doctor_id) {
    // Delete appointments associated with the doctor
    $delete_appointments_sql = "DELETE FROM appointments WHERE doctor_id = $doctor_id";
    if ($conn->query($delete_appointments_sql) === FALSE) {
        return "Error deleting appointments: " . $conn->error;
    }
    
    // Delete the doctor
    $delete_doctor_sql = "DELETE FROM doctors WHERE id = $doctor_id";
    if ($conn->query($delete_doctor_sql) === TRUE) {
        return "Doctor information deleted successfully";
    } else {
        return "Error deleting doctor: " . $conn->error;
    }
}

// Function to delete a patient by ID
function deletePatient($conn, $patient_id) {
    // Delete appointments associated with the patient
    $delete_appointments_sql = "DELETE FROM appointments WHERE patient_id = $patient_id";
    if ($conn->query($delete_appointments_sql) === FALSE) {
        return "Error deleting appointments: " . $conn->error;
    }

    // Delete the patient
    $sql = "DELETE FROM patients WHERE id = $patient_id";
    if ($conn->query($sql) === TRUE) {
        return "Patient information deleted successfully";
    } else {
        return "Error deleting patient: " . $conn->error;
    }
}


// Function to view doctor by ID
function viewDoctor($conn, $doctor_id) {
    $sql = "SELECT * FROM doctors WHERE id = $doctor_id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return "<h2>Doctor Information</h2>
                <p>ID: " . $row["id"] . "</p>
                <p>Name: " . $row["name"] . "</p>
                <p>Specialization: " . $row["specialization"] . "</p>
                <p>Phone: " . $row["phone"] . "</p>";
    } else {
        return "No doctor found with the provided ID";
    }
}

// Function to view patient by ID
function viewPatient($conn, $patient_id) {
    $sql = "SELECT * FROM patients WHERE id = $patient_id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return "<h2>Patient Information</h2>
                <p>ID: " . $row["id"] . "</p>
                <p>Name: " . $row["name"] . "</p>
                <p>Date of Birth: " . $row["dob"] . "</p>
                <p>Gender: " . $row["gender"] . "</p>
                <p>Address: " . $row["address"] . "</p>
                <p>Phone: " . $row["phone"] . "</p>";
    } else {
        return "No patient found with the provided ID";
    }
}

// Function to delete all doctors
function deleteAllDoctors($conn) {

    $delete_appointments_sql = "DELETE FROM appointments";
    if ($conn->query($delete_appointments_sql) === FALSE) {
        return "Error deleting appointments: " . $conn->error;
    }


    $sql = "DELETE FROM doctors";
    if ($conn->query($sql) === TRUE) {
        return "All doctors deleted successfully";
    } else {
        return "Error deleting doctors: " . $conn->error;
    }
}

// Function to delete all patients
function deleteAllPatients($conn) {
    // Delete appointments associated with patients
    $delete_appointments_sql = "DELETE FROM appointments";
    if ($conn->query($delete_appointments_sql) === FALSE) {
        return "Error deleting appointments: " . $conn->error;
    }

    $sql = "DELETE FROM patients";
    if ($conn->query($sql) === TRUE) {
        return "All patients deleted successfully";
    } else {
        return "Error deleting patients: " . $conn->error;
    }
}

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        if ($action === "delete_doctor" && isset($_POST['doctor_id'])) {
            $response = deleteDoctor($conn, $_POST['doctor_id']);
        } elseif ($action === "delete_patient" && isset($_POST['patient_id'])) {
            $response = deletePatient($conn, $_POST['patient_id']);
        } elseif ($action === "delete_all_doctors") {
            $response = deleteAllDoctors($conn);
        } elseif ($action === "delete_all_patients") {
            $response = deleteAllPatients($conn);
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Records</title>
</head>
<body>
    <h2>Manage Doctor and Patient Records</h2>
    
    <!-- Form to delete a doctor -->
    <h3>Delete Doctor</h3>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <input type="hidden" name="action" value="delete_doctor">
        <label for="doctor_id">Doctor ID:</label>
        <input type="text" id="doctor_id" name="doctor_id">
        <input type="submit" value="Delete Doctor">
    </form>

    <!-- Form to delete a patient -->
    <h3>Delete Patient</h3>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <input type="hidden" name="action" value="delete_patient">
        <label for="patient_id">Patient ID:</label>
        <input type="text" id="patient_id" name="patient_id">
        <input type="submit" value="Delete Patient">
    </form>
    
    <!-- Form to delete all doctors -->
    <h3>Delete All Doctors</h3>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <input type="hidden" name="action" value="delete_all_doctors">
        <input type="submit" value="Delete All Doctors">
    </form>
    
    <!-- Form to delete all patients -->
    <h3>Delete All Patients</h3>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <input type="hidden" name="action" value="delete_all_patients">
        <input type="submit" value="Delete All Patients">
    </form>
    
    <?php
    if (isset($response)) {
        echo "<p>$response</p>";
    }
    ?>
</body>
</html>
