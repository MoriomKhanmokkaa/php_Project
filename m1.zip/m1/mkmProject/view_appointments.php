<?php
include 'db.php';

$sql = "SELECT appointments.id, patients.name AS patient_name, doctors.name AS doctor_name, appointments.appointment_date
        FROM appointments
        INNER JOIN patients ON appointments.patient_id = patients.id
        INNER JOIN doctors ON appointments.doctor_id = doctors.id";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2>Appointments</h2>";
    while($row = $result->fetch_assoc()) {
        echo "<p>Appointment ID: " . $row["id"]. " - Patient: " . $row["patient_name"]. " - Doctor: " . $row["doctor_name"]. " - Date: " . $row["appointment_date"]. "</p>";
    }
} else {
    echo "<p>No appointments found.</p>";
}

$conn->close();
?>
